
let jogosFavoritos = ["MInecraft", "Clash Royaly", "clash of Clans", "Forza horizon 2", "Roblox"];

let segundoJogo = jogosFavoritos[1].toUpperCase();


console.log(segundoJogo);
