let num1 = 10 
let num2 = 25

console.log( num1 + num2);

let letra = "óla mundo"
console.log("=================");

console.log(typeof letra);

console.log("=================");

let bob = auluno = true

console.log( typeof bob);

console.log("=================");

let num3 = 3.1415

console.log(num3);