let nome = "gabriel barros da silva"

let nome1 = nome.replace("gabriel","barros","da","silva",  )
// console.log(nome);
// console.log(nome1)

console.log(nome1 );
console.log("================================================");


