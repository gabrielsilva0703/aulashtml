
let nomeCompleto = "gabriel barros da Silva";


let partesNome = nomeCompleto.split(" ");

let sobrenome = partesNome[1];


console.log(`O sobrenome é: ${sobrenome}`);
