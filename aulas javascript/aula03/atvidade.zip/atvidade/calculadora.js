
let preco = 100.00; 
let desconto = 0.2; 


let precoFinal = preco - (preco * desconto);


console.log(`O preço final com desconto é: R$${precoFinal.toFixed(2)}`);
