let nome = prompt(`Olá! Qual seu nome? `)
let idade = Number(prompt(`Qual a sua idade ?`))
let bairro = prompt(`Qual o seu bairro ?`)


// let casp = nome.toUpperCase() prompt ("insira o seu nome de ususario ") ;

// Solicita ao usuário que insira seu nome
let nomeu = nomeu.toUpperCase() = prompt("Insira o seu nome de usuário ?");

// Converte o nome para letras maiúsculas
// let casp = nomeu.toUpperCase();

let num1 = prompt("digite a um numero")
let num2 = prompt("digite a um numero")
alert(`Resultado da soma ${num1 + num2}`)




